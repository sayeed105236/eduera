
<section class="category-course-list-area">
    <div class="container">
        <div class="row">
            <div class="col" style="padding: 35px;">
                <h3>About Us</h3>
                Welcome to Global Skill. It will help you to learn in a new ways
            </div>
        </div>
    </div>
</section>
