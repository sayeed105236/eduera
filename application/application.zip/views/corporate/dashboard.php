<div class="row tile_count">
    <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
        <span class="count_top"><i class="fa fa-user"></i> Total Users</span>
        <div class="count"><?= $total_user?></div>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
      	<span class="count_top"><i class="fa fa-house-user"></i>Total Department</span>
      	<div class="count"><?=$total_department?></div>
    
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
      	<span class="count_top"><i class="fa fa-bullseye float-left"></i> Total courses</span>
      	<div class="count green"><?='2'?></div>
      	
    </div>

   
</div>

<br>
<div class="text-center">
	<h1>Dashboard are coming soon</h1>	
</div>