<h3>Your form was successfully submitted!</h3>

<p><?php echo anchor('login', 'Try it again!'); ?></p>