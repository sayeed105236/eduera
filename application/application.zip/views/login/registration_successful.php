<div class="message-page-content">
	<p class="message-page-content-title registration-success-content-title"><?php echo $page_title; ?></p>
	<p><?php echo $page_body_text; ?></p>
</div>