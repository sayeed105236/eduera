<?php include 'my_board_menu.php'; ?>
<section class="my-courses-area">
    <div class="container">
        <div class="row align-items-baseline">
            <div class="col-lg-6">
                <div class="my-course-filter-bar filter-box">
                    <span>Inbox</span>
                </div>
            </div>
            
        </div>
        <div class="container no-gutters" id = "my_courses_area">            
            <nav>

                <div class="row no-gutters" id = "my_courses_area">
                    
                </div>
            </nav>
        </div>
    </div>
</section>