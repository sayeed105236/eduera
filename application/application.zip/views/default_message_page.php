<div class="message-page-content">
	<p class="message-page-content-title"><?php echo $page_body_title; ?></p>
	<p class="message-page-content-detail"><?php echo $page_body_text; ?></p>
</div>